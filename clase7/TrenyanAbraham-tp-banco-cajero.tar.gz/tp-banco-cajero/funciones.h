#ifndef _FUNCIONES
#define _FUNCIONES

int inDevolverNumeroAleatorio(int inDesde, int inHasta);

#endif
