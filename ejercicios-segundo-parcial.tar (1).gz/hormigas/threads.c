#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "def.h"
#include "threads.h"
#include "colas.h"
#include "funciones.h"

void *funcionThread(void *param) {

	int id, id_cola_mensajes, recoleccion;
	int hojas=0, comida=0, palos=0, piedras=0;
	int done = 0;	
	mensaje msg;
	char buffer[100];
	
	thormiga *datos_thread = (thormiga*) param;

	id = datos_thread->id;
	id_cola_mensajes = datos_thread->id_cola_mensajes;

	memset(buffer, 0x00, sizeof(buffer));

	while(done == 0) {
		printf("\n-----------------------------");
		
		recibir_mensaje(id_cola_mensajes, id, &msg);
	
		pthread_mutex_lock(&mutex);
		switch(msg.evento) {
			case EVT_HOJA:
				recoleccion = num_random(1, 7);
				hojas += recoleccion;
			
				printf("\nID Hormiga %d: ha recolectado %d hojas", id, recoleccion);
		
				sprintf(buffer, "%d|%d|%d", id, hojas, EVT_HOJA);		
				enviar_mensaje(id_cola_mensajes, MSG_REINA, id, EVT_RECOLECTADO, buffer);
				
			break;

			case EVT_COMIDA:
				recoleccion = num_random(1, 7);
				comida += recoleccion;
			
				printf("\nID Hormiga %d: ha recolectado %d de comida", id, recoleccion);
		
				sprintf(buffer, "%d|%d|%d", id, comida, EVT_COMIDA);		
				enviar_mensaje(id_cola_mensajes, MSG_REINA, id, EVT_RECOLECTADO, buffer);
				
			break;

			case EVT_PIEDRA:
				recoleccion = num_random(1, 7);
				piedras += recoleccion;
			
				printf("\nID Hormiga %d: ha recolectado %d de piedra", id, recoleccion);
		
				sprintf(buffer, "%d|%d|%d", id, piedras, EVT_PIEDRA);		
				enviar_mensaje(id_cola_mensajes, MSG_REINA, id, EVT_RECOLECTADO, buffer);
				
			break;

			case EVT_PALO:
				recoleccion = num_random(1, 7);
				palos += recoleccion;
			
				printf("\nID Hormiga %d: ha recolectado %d palos", id, recoleccion);
		
				sprintf(buffer, "%d|%d|%d", id, palos, EVT_PALO);		
				enviar_mensaje(id_cola_mensajes, MSG_REINA, id, EVT_RECOLECTADO, buffer);
				
			break;

			case EVT_FIN:
				printf("\nID Hormiga %d: Se retira por hoy.", id);
				done = 1;
			break;
			default:
				printf("\nSin evento definido");
			break;
		}
		
		pthread_mutex_unlock(&mutex);
		sleep(1);
	}

	pthread_exit((void*) "Listo");

}
