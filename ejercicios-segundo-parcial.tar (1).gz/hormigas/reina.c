#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "colas.h"
#include "def.h"
#include "funciones.h"

int main(int argc, char *argv[]) {

	int id_hormiga, evt_recurso, recurso, total; 
	int id_cola_mensajes, i, done = 0;
	char *buffer;
 	char *tok;
	mensaje msg;

	id_cola_mensajes = creo_id_cola_mensajes();	
	borrar_mensajes(id_cola_mensajes);

	/* Limpio memoria */
        buffer = (char*) malloc(sizeof(char)*(LENGTH+1));
	tok = (char*) malloc(sizeof(char)*(LENGTH+1));
        memset(buffer, 0x00, sizeof(buffer));
	memset(tok, 0x00, sizeof(tok));

	srand(time(NULL));	

	while(done == 0) {
		
		for(i=0; i<CANT_HORMIGAS; i++) {
			evt_recurso = num_random(RECURSO_DESDE, RECURSO_HASTA);
			enviar_mensaje(id_cola_mensajes, MSG_HORMIGA+i, MSG_REINA, evt_recurso, buffer);
		}
		
		recibir_mensaje(id_cola_mensajes, MSG_REINA, &msg);

		switch(msg.evento) {
			case EVT_RECOLECTADO:
				tok = strtok(msg.mensaje, "|");
				id_hormiga = atoi(tok);

				tok = strtok(0, "|");
				total = atoi(tok);

				tok = strtok(0, "|");
				recurso = atoi(tok);

				sprintf(buffer, "%s", recurso_by_id(recurso));

				printf("\nID Hormiga %d: Ha recolectado %d de %s", id_hormiga, total, buffer);

				if(total >= MAX) {
					
					printf("\nID Hormiga %d: Ha completado su tarea con %d de %s\n", id_hormiga, total, buffer);
					done = 1;
				
					enviar_mensaje(id_cola_mensajes, msg.origen, MSG_REINA, EVT_FIN, buffer);
				
				} else {
				
					evt_recurso = num_random(RECURSO_DESDE, RECURSO_HASTA);
					enviar_mensaje(id_cola_mensajes, msg.origen, MSG_REINA, evt_recurso, buffer);

				}

			break;

		}

		sleep(1);
	}

	for(i=0; i<CANT_HORMIGAS; i++) {
		enviar_mensaje(id_cola_mensajes, MSG_HORMIGA+i, MSG_REINA, EVT_FIN, "Fin");
	}

	free(buffer);

	return 0;	
}

