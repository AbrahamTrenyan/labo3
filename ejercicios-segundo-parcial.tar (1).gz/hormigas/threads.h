#ifndef _THREADS_H
#define _THREADS_H

typedef struct tipo_hormiga {
	int id;
	int id_cola_mensajes;
} thormiga;

pthread_mutex_t mutex;

void *funcionThread(void *param);

#endif
