#include <stdlib.h>
#include "def.h"

int num_random(int desde, int hasta) {
	return rand()%(hasta-desde)+desde;
}

char* recurso_by_id(int recurso_id) {

	switch(recurso_id) {
		case EVT_HOJA:
			return "hojas";
		break;
		case EVT_COMIDA:
			return "comida";
		break;
		
		case EVT_PALO:
			return "palos";
		break;

		case EVT_PIEDRA:
			return "piedras";
		break;

	}
	return "";
}

