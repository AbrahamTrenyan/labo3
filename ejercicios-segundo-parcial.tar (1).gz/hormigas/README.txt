Se recomienda ejecutar primero ./pista para limpiar la cola de mensajes
