#ifndef _DEF_H
#define _DEF_H

#define COMANDO "/bin/ls"
#define VALOR_CLAVE 33
#define ROJO 0
#define VERDE 1
#define LENGTH 100
#define CANTIDAD 10

#define RECURSO_DESDE 1
#define RECURSO_HASTA 4

#define MSG_REINA 1
#define MSG_HORMIGA 2

#define EVT_FIN -1
#define EVT_HOJA 1
#define EVT_COMIDA 2
#define EVT_PALO 3
#define EVT_PIEDRA 4
#define EVT_RECOLECTADO 5

#define CANT_HORMIGAS 4
#define MAX 10

#endif
