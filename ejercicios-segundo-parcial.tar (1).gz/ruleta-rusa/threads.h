#ifndef _THREADS_H
#define _THREADS_H

typedef struct tipo_jugador {
	int id;
	int id_cola_mensajes;
	int posicion_disparo;
} tjugador;

pthread_mutex_t mutex;

void *funcionThread(void *param);

#endif
