#ifndef _FUNCIONES_H
#define _FUNCIONES_H

int num_random(int, int);

#endif
