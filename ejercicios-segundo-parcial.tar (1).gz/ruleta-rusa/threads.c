#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "def.h"
#include "threads.h"
#include "colas.h"
#include "funciones.h"

void *funcionThread(void *param) {

	int id, id_cola_mensajes, posicion_disparo;
	int done = 0;	
	mensaje msg;
	char buffer[100];
	
	tjugador *datos_thread = (tjugador*) param;

	id = datos_thread->id;
	id_cola_mensajes = datos_thread->id_cola_mensajes;

	memset(buffer, 0x00, sizeof(buffer));

	while(done == 0) {
		printf("\n-----------------------------");
		
		recibir_mensaje(id_cola_mensajes, id, &msg);
	
		pthread_mutex_lock(&mutex);
		switch(msg.evento) {
			case EVT_INICIO:
			case EVT_SALVADO:
				posicion_disparo = num_random(BALA_DESDE, BALA_HASTA);
			
				printf("\nID Jugador %d: Dispara en posicion %d", id, posicion_disparo);
		
				sprintf(buffer, "%d|%d", id, posicion_disparo);		
				enviar_mensaje(id_cola_mensajes, MSG_RULETA, id, EVT_DISPARO, buffer);
				
			break;

			case EVT_FIN:
				printf("\nID Jugador %d: Se retira del juego.", id);
				done = 1;
			break;
			default:
				printf("\nSin evento definido");
			break;
		}
		
		pthread_mutex_unlock(&mutex);
		sleep(1);
	}

	pthread_exit((void*) "Listo");

}
