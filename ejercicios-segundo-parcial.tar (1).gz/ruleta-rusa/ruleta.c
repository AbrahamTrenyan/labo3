#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "colas.h"
#include "def.h"
#include "funciones.h"

int main(int argc, char *argv[]) {

	int id_jugador, posicion_disparo, bala; 
	int id_cola_mensajes, i, done = 0;
	char *buffer;
 	char *tok;
	mensaje msg;

	id_cola_mensajes = creo_id_cola_mensajes();	
	borrar_mensajes(id_cola_mensajes);

	/* Limpio memoria */
        buffer = (char*) malloc(sizeof(char)*(LENGTH+1));
	tok = (char*) malloc(sizeof(char)*(LENGTH+1));
        memset(buffer, 0x00, sizeof(buffer));
	memset(tok, 0x00, sizeof(tok));

	srand(time(NULL));	
	
	/* Defino posicion de la bala */
	bala = num_random(BALA_DESDE, BALA_HASTA);

	while(done == 0) {
		
		for(i=0; i<CANT_JUGADORES; i++) {
			enviar_mensaje(id_cola_mensajes, MSG_JUGADOR+i, MSG_RULETA, EVT_INICIO, buffer);
		}
		
		recibir_mensaje(id_cola_mensajes, MSG_RULETA, &msg);

		switch(msg.evento) {
			case EVT_DISPARO:
				tok = strtok(msg.mensaje, "|");
				id_jugador = atoi(tok);

				tok = strtok(0, "|");
				posicion_disparo = atoi(tok);

				printf("\nID Jugador: %d disparo bala %d", id_jugador, posicion_disparo);

				if(posicion_disparo == bala) {
					
					enviar_mensaje(id_cola_mensajes, msg.origen, MSG_RULETA, EVT_FIN, buffer);
					printf("\nID Jugador %d: Ha perdido el juego\n", id_jugador);
					done = 1;
				} else {
					enviar_mensaje(id_cola_mensajes, msg.origen, MSG_RULETA, EVT_SALVADO, buffer);
				}
				
			break;

		}

		sleep(1);
	}

	for(i=0; i<CANT_JUGADORES; i++) {
		enviar_mensaje(id_cola_mensajes, MSG_JUGADOR+i, MSG_RULETA, EVT_FIN, "Fin");
	}

	free(buffer);

	return 0;	
}

