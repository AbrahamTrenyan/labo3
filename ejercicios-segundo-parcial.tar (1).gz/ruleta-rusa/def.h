#ifndef _DEF_H
#define _DEF_H

#define COMANDO "/bin/ls"
#define VALOR_CLAVE 33
#define ROJO 0
#define VERDE 1
#define LENGTH 100
#define CANTIDAD 10

#define BALA_DESDE 1
#define BALA_HASTA 6

#define MSG_RULETA 1
#define MSG_JUGADOR 2

#define EVT_FIN -1
#define EVT_INICIO 1
#define EVT_DISPARO 2
#define EVT_SALVADO 3

#define CANT_JUGADORES 6

#endif
