#ifndef _FUNCIONES
#define _FUNCIONES

void derivar(int cant_productos, char *sistema);
void procesar_bebida(char *nombreArchivo, char sistema, char *buffer);
void obtener_sistema(int argc, char *argv[], char *sistema);
int inDevolverNumeroAleatorio(int inDesde, int inHasta);
#endif
