
Centro de logística con control:

En una entidad de logística, se destina por medio de un sistema de control (llamado "Logiarg") la realización y la derivación de diversos productos que manejan en sus depósitos. En este caso se manejará un depósito que distribuye bebidas; cada tipo de bebida se separa en tandas de: 10, 20 y 30 bebidas (aleatorio 1 a 3, o ingreso por teclado). Pero las bebidas pueden ser alcohólicas como no alcohólicas. Aleatoriamente se elige si es alcohólica o no. (1 a 2). 

Independientemente de si es alcohólica o no, se deriva según su cantidad al sistema de control, siendo el sistema A(10 bebidas), el sistema B (20 bebidas) y el sistema C(30 bebidas) donde se distribuyen. 

Se contará con un array (arreglo) de estructuras, en la que cada estructura cuenta con el nombre de la bebida, si es alcohólica o no, (y descripción si desea). Evalué si colocaría cantidad o no.  

Dependiendo la cantidad de unidades se dirigirá a cada sistema de control. Se contará con un proceso por cada sistema de control (3 sistemas).
Para comunicar puede/debe utilizarse semáforo y/o archivos.
En total son 4 procesos corriendo en forma simultánea.
Se debe mostrar la actividad de cada proceso. 
