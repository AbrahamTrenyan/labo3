#ifndef _FUNCIONES
#define _FUNCIONES

int inDevolverNumeroAleatorio(int inDesde, int inHasta);
int inDevolverNumeroAleatorioNoRepetitivo(int numerosAleatorios[], int inDesde, int inHasta);
#endif
