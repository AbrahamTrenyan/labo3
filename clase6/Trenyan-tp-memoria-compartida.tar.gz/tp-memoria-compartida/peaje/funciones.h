#ifndef _FUNCIONES
#define _FUNCIONES

int inDevolverNumeroAleatorio(int inDesde, int inHasta);
void registrar_liberacion(char *buffer, int *cantidad_de_liberaciones);
void obtener_via_con_menos_vehiculos(int *vehiculos_en_cola, int cantidad_de_vias, int *via_seleccionada, int *minimo, int *i);
void obtener_cantidad_de_vias(int argc, char *argv[], int *cantidad_de_vias);
#endif
