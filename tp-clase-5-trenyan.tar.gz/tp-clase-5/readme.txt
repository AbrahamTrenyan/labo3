COMPILACION: make(borra los archivos lote.dat existentes)

EJECUCION:
1. Terminal 1: ./carga (inicializa semaforo, carga vuelos a lote.dat, Ctrl+C para salir)
2. Terminal 2: ./reservas (procesa lotes automaticamente, dejar corriendo y probar ejecutando cargas varias veces, Ctrl+C para salir)


