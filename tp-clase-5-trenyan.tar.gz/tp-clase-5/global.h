#ifndef _GLOBAL
#define _GLOBAL

extern int id_semaforo;
extern int contador_lotes;
extern int vuelos[11];

#endif
