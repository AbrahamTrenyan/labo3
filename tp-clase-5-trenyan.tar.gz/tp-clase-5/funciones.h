#ifndef _FUNCIONES
#define _FUNCIONES

void mostrar_resumen(void);
void agregar_pasajero(int vuelo);

#endif
