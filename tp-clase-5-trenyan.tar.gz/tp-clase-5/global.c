#include "global.h"

int id_semaforo;
int contador_lotes = 0;
int vuelos[11];  /* Indices para vuelos 1000-1010 */
