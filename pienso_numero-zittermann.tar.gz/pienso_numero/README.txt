La cantidad de jugadores debe enviarse al ejecutable como primer 
parametro.
