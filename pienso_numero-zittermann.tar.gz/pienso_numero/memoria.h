#ifndef _MEMORIA_H
#define _MEMORIA_H

void* creo_memoria(int, int*);

#endif
