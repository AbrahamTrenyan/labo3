#include <pthread.h>

pthread_mutex_t mutex;

