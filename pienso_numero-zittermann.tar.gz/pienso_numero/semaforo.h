#ifndef _SEMAFORO_H
#define _SEMAFORO_H

int creo_semaforo();
void iniciar_semaforo(int, int);
void levantar_semaforo(int);
void esperar_semaforo(int);

#endif

