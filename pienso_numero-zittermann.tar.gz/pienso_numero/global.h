#ifndef _GLOBAL_H
#define _GLOBAL_H

pthread_mutex_t mutex;

#endif
