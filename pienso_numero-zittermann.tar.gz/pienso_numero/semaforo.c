#include "clave.h"
#include "def.h"
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>

int creo_semaforo() {

	key_t clave = creo_clave(COMANDO, VALOR_CLAVE);
	int id_semaforo = semget(clave, 1, 0600|IPC_CREAT);

	if(id_semaforo == -1) {
		printf("Error: Could not create semaphore.\n");	
	}
	
	return id_semaforo;

}

void iniciar_semaforo(int id_semaforo, int valor) {

	semctl(id_semaforo, 0, SETVAL, valor);

}

void levantar_semaforo(int id_semaforo) {

	struct sembuf operacion;
	operacion.sem_num = 0;
	operacion.sem_op = 1; /* Increase semaphore to 1 */
	operacion.sem_flg = 0;

	semop(id_semaforo, &operacion, 1);

}

void esperar_semaforo(int id_semaforo) {

	struct sembuf operacion;
	operacion.sem_num = 0;
	operacion.sem_op = -1; /* Decrease semaphore to -1 */
	operacion.sem_flg = 0;

	semop(id_semaforo, &operacion, 1);

}


