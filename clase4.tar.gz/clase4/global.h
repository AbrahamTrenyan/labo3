#ifndef _GLOBAL
#define _GLOBAL

extern int inVariableGlobal;

typedef struct {
    char nombre[50];
    int legajo;
    int sueldo;   
} Empleado;

#endif
