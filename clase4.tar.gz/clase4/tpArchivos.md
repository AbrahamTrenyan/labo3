para compilar: 
make
ejecutar en este orden
./productor
./consumidor