#include <stdio.h>
#include <stdlib.h>
int inVariableGlobal = 0;
