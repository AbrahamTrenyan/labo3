/* el def.h se usa para constantes como el finals en lenguajes de alto nivel*/
#ifndef _DEF
#define _DEF

#define TRUE 1
#define FALSE 0

#define CANTIDAD 10
#define DESDE 0
#define HASTA 10

#endif
