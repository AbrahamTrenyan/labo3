#include "global.h"

int id_semaforo;
