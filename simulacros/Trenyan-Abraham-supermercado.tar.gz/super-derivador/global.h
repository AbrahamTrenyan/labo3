#ifndef _GLOBAL
#define _GLOBAL

extern int id_semaforo;

struct producto{
	int precio;
	char descripcion[255+1];
} Producto;
#endif
