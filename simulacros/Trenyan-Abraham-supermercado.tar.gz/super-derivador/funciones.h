#ifndef _FUNCIONES
#define _FUNCIONES

void derivar(int cant_productos, int *nroCaja);
void procesar_pedido(char *nombreArchivo, int nroCaja);
void obtener_numero_caja(int argc, char *argv[], int *nroCaja);

#endif
