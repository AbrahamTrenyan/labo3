#ifndef _threads_h
#define _threads_h

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

pthread_mutex_t mutex;
/* extern pthread_t idHilo; */
pthread_attr_t atributos;

/*
void *funcionThread (void *parametro);

*/




#endif

