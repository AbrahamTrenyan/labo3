#ifndef _FUNCIONES_H
#define _FUNCIONES_H

int devolverNumeroAleatorio(int minimo, int maximo);

void generarNumerosNoRepetidos(int *array, int topeBucle, int minimo, int maximo);

void activarFlag(void);

void esperarFlag(void);


#endif

