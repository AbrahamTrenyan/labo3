#ifndef _clave_h
#define _clave_h



#include <sys/ipc.h>

key_t creoClave(void);

#endif
