#ifndef _FUNCIONES
#define _FUNCIONES

int inDevolverNumeroAleatorio(int inDesde, int inHasta);
void inDevolverNumeroAleatorioNoRepetitivo(int numerosAleatorios[], int inDesde, int inHasta);
int obtenerCantidadJugadores(int argc, char *argv[]);

#endif
