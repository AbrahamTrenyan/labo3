#ifndef _GLOBAL
#define _GLOBAL

#include <pthread.h>

extern pthread_mutex_t mutex;

#endif

