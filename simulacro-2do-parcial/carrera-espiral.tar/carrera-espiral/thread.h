#ifndef _THREAD
#define _THREAD

void *thread_jugador(void *parametro);

#endif
