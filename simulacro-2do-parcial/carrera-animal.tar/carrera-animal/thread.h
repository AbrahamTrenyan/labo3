#ifndef _THREAD
#define _THREAD

void *thread_animal(void *parametro);

#endif
