#ifndef MEMORIA_H
#define MEMORIA_H

void *creo_memoria(int size, int *r_id_memoria, int clave_base);

#endif
