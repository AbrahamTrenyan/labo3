#ifndef _FUNCIONES_H
#define _FUNCIONES_H

int num_random(int, int);

char* recurso_by_id(int);

#endif
