Se recomienda ejecutar primero el proceso ./espiral para limpiar la cola 
de mensajes
